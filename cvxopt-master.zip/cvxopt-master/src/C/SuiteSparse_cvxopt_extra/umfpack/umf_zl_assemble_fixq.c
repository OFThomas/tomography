#define ZLONG
#define FIXQ
#include "umf_assemble.c"
