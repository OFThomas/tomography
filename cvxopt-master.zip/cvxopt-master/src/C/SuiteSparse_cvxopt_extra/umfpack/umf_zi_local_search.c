#define ZINT
#include "umf_local_search.c"
