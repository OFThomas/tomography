#define DINT
#include "umf_mem_alloc_head_block.c"
