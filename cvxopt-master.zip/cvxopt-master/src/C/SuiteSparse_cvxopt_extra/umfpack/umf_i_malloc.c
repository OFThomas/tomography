#define DINT
#include "umf_malloc.c"
