#define DLONG

#include "amd_preprocess.c"
