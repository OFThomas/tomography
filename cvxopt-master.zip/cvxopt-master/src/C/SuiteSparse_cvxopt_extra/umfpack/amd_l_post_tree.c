#define DLONG

#include "amd_post_tree.c"
