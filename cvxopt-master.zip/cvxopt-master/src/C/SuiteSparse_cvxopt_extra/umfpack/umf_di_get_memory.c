#define DINT
#include "umf_get_memory.c"
