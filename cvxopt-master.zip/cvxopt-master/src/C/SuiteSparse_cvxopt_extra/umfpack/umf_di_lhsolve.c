#define DINT
#define CONJUGATE_SOLVE
#include "umf_ltsolve.c"
