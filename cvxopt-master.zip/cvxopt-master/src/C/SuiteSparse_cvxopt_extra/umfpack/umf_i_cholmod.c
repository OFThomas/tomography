#define DINT
#include "umf_cholmod.c"
