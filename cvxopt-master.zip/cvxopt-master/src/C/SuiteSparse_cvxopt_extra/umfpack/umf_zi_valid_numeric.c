#define ZINT
#include "umf_valid_numeric.c"
