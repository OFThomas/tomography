#define DINT
#include "umf_valid_numeric.c"
