#define ZINT
#include "umf_garbage_collection.c"
