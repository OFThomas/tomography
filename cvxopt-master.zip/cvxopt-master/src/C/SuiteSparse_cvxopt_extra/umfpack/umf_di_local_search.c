#define DINT
#include "umf_local_search.c"
