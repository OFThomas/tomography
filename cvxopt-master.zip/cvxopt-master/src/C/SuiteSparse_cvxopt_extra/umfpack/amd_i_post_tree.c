#define DINT

#include "amd_post_tree.c"
