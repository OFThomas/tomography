#define DINT
#include "umfpack_free_numeric.c"
