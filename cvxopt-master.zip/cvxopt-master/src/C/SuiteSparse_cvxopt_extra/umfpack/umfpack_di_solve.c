#define DINT
#include "umfpack_solve.c"
