#define ZINT

#include "umf_init_front.c"
